<?php
include("../library/library.php");
$menu = new Menu();
$err="";
$header = new Header();
$footer = new Footer();

$header->writeHeader();
$menu->writeMenu("home");

?>
<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>World Comm.-CT CRM</h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<div class="row">
		<hr>
		<h4>Welcome, Bruce Wayne!</h4>
	</div>
	<div class="row">
		<div class="col-md-8">
			<a href="myInfo.php"><button class="btn btn-primary btn-lg" style="height:100px;"><span class="glyphicon glyphicon-cog"></span><br>User Account</button></a>
			<a href="../salesManagementModule/addSale.php"><button class="btn btn-warning btn-lg" style="height:100px;"><span class="glyphicon glyphicon-plus"></span><br>Add Sales</button></a>
		</div>
	</div>
	<br>
	<div class="row">
		
		<h3>Modules</h3>
		<hr>
	</div>
	<div class="row">
		<div class="col-md-4">
			<h4>Membership Module</h4>

<p><strong>Actor: Employee</strong> </p>

<ul>
<li>Add Membership</li>
<li>Update Membership Profile</li>
<li>View Membership Detail</li>
<li>Activate VIP</li>
<li>Redeem Credit</li>
<li>Add Credit</li>
<li>Redeem VIP Privileges</li>
<li>View Credit Transaction</li>
<li>View Requests Status</li>
<li>Search Membership with ID</li>
</ul>

<p><strong>Actor: Admin</strong></p>

<ul>
<li>Manage All Memberships</li>
<li>Manage Credit Requests</li>
<li>Manage Referral Request</li>
</ul>

		</div>
		
		<div class="col-md-4">
					<h4>Employee Module</h4>
					
<p><strong>Actor: Employee</strong></p>

<ul>
<li>View Personal Info </li>
<li>Update Personal Info</li>
<li>Update Password</li>
<li>Register Account</li>
<li>View Strikes</li>
<li>Log in to CRM</li>
</ul>

<p><strong>Actor: Admin</strong></p>

<ul>
<li>View Employee List</li>
<li>Suspend Employee Account</li>
<li>Update Employees Info</li>
<li>View Strikes</li>
<li>Delete Strikes</li>
<li>Modify Strikes</li>
</ul>
		</div>
		<div class="col-md-4">
					<h4>Sales Module</h4>
					
<p><strong>Actor: Employee</strong></p>

<ul>
<li>Review Sales Targets</li>
<li>Add New Sale</li>
<li>View Daily Sales</li>
<li>View Sale</li>
<li>Delete Sale</li>
<li>Get Receipt Code</li>
<li>Search Sales</li>
<li>Process Return</li>
<li>Update Sale</li>
<li>View Daily Sales Summary</li>
<li>Send Daily Sales Summary Report</li>
</ul>

<p><strong>Actor: Admin</strong></p>

<ul>
<li>Mangage Sales</li>
	<ul>
		<li>View Periodic Sales</li>
		<li>View Sale Detail</li>
		<li>Delete Sale</li>
		<li>Get receipt</li>
	</ul>
<li>View Model Trends</li>
<li>Manage Sales Target</li>
	<ul>
		<li>Set Sales Targets</li>
		<li>View Sales Progress</li>
	</ul>
</ul>
	
		
	</div>
				
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>















