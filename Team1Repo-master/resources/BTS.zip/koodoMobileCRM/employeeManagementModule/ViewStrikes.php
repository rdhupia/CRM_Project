
<?php

   include("../library/library.php");
	$menu = new Menu();
	$err="";
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("View Strikes");
	
?>
    
	<h2 class="text-center"> Strikes </h2><hr>
	<div class ="center-block" style="width:70%;min-width:325px;">
		<table class="table table-striped">
			<tr>
				<th style="width:20%;" > date </th>
				<th> Reason </th>
			</tr>
			<tr>
				<td> Filler </td>
				<td> Filler </td>
			</tr>
		</table>
	</div>


<?php
	$footer->writeFooter();
?>














