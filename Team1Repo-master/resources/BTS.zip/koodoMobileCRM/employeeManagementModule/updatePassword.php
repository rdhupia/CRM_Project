<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$err="";
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("Login");
	?>

		<!-- MAIN CONTENT -->
		<div class="main-content container-fluid">
			<h3>Change Password</h3><br>
			<form class="form-horizontal" method="post">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<div class="form-group">
					<label class="control-label  col-md-4" style="min-width:180px;">Current password</label>
						<div class="col-md-16">
							<input class="form-control" name="currentPassword" type="password" >
						</div>
					</div>	
					<div class="form-group">
						<label class="control-label  col-md-4"style="min-width:180px;">New password</label>
							<div class="col-md-16">
								<input class="form-control" name="newPassword" type="password" >
							</div>
					</div>	
					<div class="form-group">
						<label class="control-label  col-md-4"style="min-width:180px;">Confirm password</label>
							<div class="col-md-16">
								<input class="form-control" name="confirmPassword" type="password" >
							</div>
						</div>
					</div>
				</div>
				
					<div class="form-group">
						<label class="col-md-4"></label>
						<div class="col-md-4">
						<!--<input class="form-control" type="submit" value="Submit">-->
						<a href="myInfo.php" class="btn btn-success col-md-12">Submit</a>
					</div>
				</div>
				</div>
		</form>
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>