 <?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	
	$header->writeHeader();
	$menu->writeMenu("MyInfo");
?>

<body>
	<div class="container body-content">
		<div class="row">
			<h3>Manage users</h3>
		</div>	
		<br>
		<hr>
		<br>
		
		<div class="table-responsive">
			  <table class="table table-bordered table-hover">
			  	<thead>
			  		<tr>
			  			<th class="col-sm-1 col-md-1">USER NAME</th>
			  			<th class="col-sm-1 col-md-1">FIRST NAME</th>
			  			<th class="col-sm-1 col-md-1">LAST NAME</th>
			  			<th class="col-sm-1 col-md-1">POS SYSTEM USET ID</th>
			  			<th class="col-sm-2 col-md-2">PHONE NUMBER</th>
			  			<th class="col-sm-2 col-md-2">EMAIL ADDRESS</th>
			  			<th class="col-sm-1 col-md-1">HOME ADDRESS</th>
			  			<th class="col-sm-1 col-md-1">STRIKES</th>
						<th class="col-sm-1 col-md-1">ACTIONS</th>
			  		</tr>
			  	</thead>
				
				<tbody>
				<tr>
					<td>user312</td>
					<td>Bob</td>
					<td>Bobbals</td>
					<td>1341234</td>
					<td> 416-555-8008 </td>
					<td>Example@gmail.com </td>
					<td>69 road ave</td>
					<td><a href=StrikeManager.php ><button class="btn btn-primary btn-sm">1</button></a></td>
					<td>
						<div class="btn-group" role="group" aria-label="...">
							<a href="./EditUser.php"><button type="button" class="btn btn-default"  data-toggle="tooltip" title="Edit" >
								<span class="glyphicon glyphicon-pencil" ></span> 
							</button></a>
							<button type="button" class="btn btn-default"  data-toggle="tooltip" title="Suspend">
								<span class="glyphicon glyphicon-lock"></span> 
							</button>
						</div>
					</td> 	
						   
				</tr>
				</tbody>
		    </table>
		</div> 
		<!--- /TABLE-RESPONSIVE -->
		
	</div>
<?php
	$footer->writeFooter();
?>