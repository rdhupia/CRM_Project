<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$firstName="firstfiller";
	$lastName="lastfiller";
	$POS="filler";
	$phoneNumber="filler";
	$emailAddress="filler@filler.com";
	$homeAddress="69 filler ave.";
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("MyInfo");
	?>
<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>My Information</h2>
	</div>
</header>
<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container-fluid">
		
		<form method=post class=form-group>
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<table class="table">
						<tr>
							<td>Name:</td>
							<td>
							<?php
								echo $firstName . " ". $lastName;
							?>
						</td>
						
						</tr>
						
						<tr>
						<td>
							POS System uset id:
						</td>
						<td>
							<?php
								echo $POS;
							?>
						</td>
						</tr>
						<tr>
						<td>
							Phone number:
						</td>
						<td>
							<?php
								echo $phoneNumber;
							?>
						</td>
						<td>
							<a  class=button href=updateInfo.php >Edit</a>
						</td>
						</tr>
						
						<tr>
						<td>
							Email address:
						</td>
						<td>
							<?php
								echo $emailAddress;
							?>
						</td>
						</tr>
						
						<tr>
						<td>
							Home address:
						</td>
						<td>
							<?php
								echo $homeAddress;
							?>
						</td>
						</tr>
						
						
						</table>
						</form>
						</div>
				</div>
			</div>
		
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>