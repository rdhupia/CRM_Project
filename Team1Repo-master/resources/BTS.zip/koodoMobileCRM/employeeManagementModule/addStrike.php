<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$err="";
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("addStrike");
	?>

		<!-- MAIN CONTENT -->
		<div class="main-content container-fluid">
		<h4>Striking:[employee name]</h4><hr>
		<form method=post class=form-horizontal>
		<div class="form-group">
			
			<label for="reason" class="control-label col-sm-2 control-label">Reason</label>  
			<div class="col-sm-10">
				<textarea class=form-control rows=4 placehold=Reasons></textarea>
			</div>
		</div>
		<hr>
		<div ">
			<input type="submit" value="Submit" class="btn btn-success btn-lg" />
		</div>
		</form>
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>