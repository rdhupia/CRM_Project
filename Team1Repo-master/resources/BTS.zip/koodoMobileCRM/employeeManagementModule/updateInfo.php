<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$err="";
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("Update Information");
	?>

		<!-- MAIN CONTENT -->
		<div class="main-content container">
		<h3>Update Information</h3><br>
		
		<form class="form-horizontal" method="post">
			<div class="row">
				<div class="col-md-6">
					
					<div class="form-group">
						<label class="control-label  col-md-4">Phone Number</label>
						<div class="col-md-16">
							<input class="form-control" name="phoneNumber" placeholder="xxx xxx-xxxx" >
						</div>
					</div>
					<div class="form-group">
						<label class="control-label  col-md-4">Email Address</label>
						<div class="col-md-16">
							<input class="form-control" name="emailAddress" placeholder="Email Address" >
						</div>
					</div>
					<div class="form-group">
						<label class="control-label  col-md-4">Home Address</label>
						<div class="col-md-16">
							<input class="form-control" name="homeAddress" placeholder="Home Address" >
						</div>
					</div>
					
					</div>
					</div>
					
				<div class="form-group">
				<label class="col-md-4"></label>
				<div class="col-md-4">
					<!--<input class="form-control" type="submit" value="Submit">-->
					<a href="viewMembership.php" class="btn btn-success col-md-12">Submit</a>
				</div>
			</div>
		</form>
		</div>

<?php
	$footer->writeFooter();
?>