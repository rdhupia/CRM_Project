<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$err="";
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("Register");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
			<h2>Edit [Employee Name]</h2><br>
			</div>
		</header>
		<!-- MAIN CONTENT -->
		<div class="main-content container-fluid">
			<form class="form-horizontal" method="post">
			<h3>Employee Information</h3>
				<div class="form-group">
					<label class="col-sm-2 control-label">Phone Number</label>
					<div class="col-sm-4">
						<input class="form-control" name="phoneNumber" placeholder="xxx xxx-xxxx" >
					</div>
					<label class="col-sm-2 control-label">Email Address</label>
					<div class="col-sm-4">
						<input class="form-control" name="emailAddress" placeholder="Email Address" >
					</div>
					<label class="col-sm-2 control-label">Home Address</label>
					<div class="col-sm-4">
						<input class="form-control" name="homeAddress" placeholder="Home Address" >
					</div>
				</div>
					<hr>
					<div class="col-md-6">
					
					
					<h3>Login Details</h3><br>
					<div class="form-group">
						<label class="control-label  col-md-4">Password</label>
						<div class="col-md-8">
							<input class="form-control" name="password"  type="password">
						</div>
						<label class="control-label  col-md-4">Confirm Password</label>
						<div class="col-md-8">
							<input class="form-control" name="confirmPassword" type="password">
						</div>
						<div class="span1">
						<!--<input class="form-control" type="submit" value="Submit">-->
						<a href="viewMembership.php" class="btn btn-success btn-lg">Submit</a>
						</div>
				</div>
			</div>	
			
		</form>
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>