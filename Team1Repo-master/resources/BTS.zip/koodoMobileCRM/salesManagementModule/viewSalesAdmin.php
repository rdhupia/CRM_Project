<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("admin");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>View Sales</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container">
			<form class="form-inline">
				<div class="form-group">
					<label for="start-date">Start Date</label>
						<input id="start-date" type="date" value="2014-10-17">
					<label for="end-date">End Date</label>
						<input id="end-date" type="date" value="2015-10-17">
				</div>
				<div class="form-group">
					<label for="storeLocation">Store </label>
					<select class="form-control" name="cusProvince" id="storeLocation">
						<option value="none">None</option>
						<option value="Sheridan">Sheridan</option>
						<option value="Jane">Jane</option>
						<option value="Woodside">Woodside</option>
						<option value="Trethewey">Trethewey</option>
					</select>
				</div>	
				<div class="form-group">
				<button type="submit" class="btn btn-primary">Search</button>
				<button type="submit" class="btn btn-success">View All</button>
				</div>
			</form>
			<h3>Sales List</h3>
			<div class="form-group">
				<div class="dropdown">
					<button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Display Sales <span class="caret"></span>
					</button>
					<ul class="dropdown-menu noOfRows" aria-labelledby="dropdownMenu1">
						<li><a href="#" value="10">10 per page</a></li>
						<li><a href="#" value="20">20 per page</a></li>
						<li><a href="#" value="30">30 per page</a></li>
						<li><a href="#" value="40">40 per page</a></li>
					</ul>
				</div>
				
			</div>
			<!-- TABLE-RESPONSIVE -->
			<div class="table-responsive">
			  <table class="table table-bordered table-hover">
			  	<thead>
			  		<tr>
			  			<th class="col-sm-1 col-md-1">SALE ID</th>
			  			<th class="col-sm-1 col-md-1">SALES PERSON</th>
			  			<th class="col-sm-2 col-md-2">PHONE#</th>
			  			<th class="col-sm-1 col-md-1">PHONE MODEL</th>
			  			<th class="col-sm-2 col-md-2">IMEI#</th>
			  			<th class="col-sm-2 col-md-2">SIM#</th>
			  			<th class="col-sm-1 col-md-1">SALE TYPE</th>
						<th class="col-sm-2 col-md-2">ACTIONS</th>
			  		</tr>
			  	</thead>
				
				<tbody>
				<?php for ($x = 1; $x <= 10; $x++) {
					?>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td>
							<div class="btn-group" role="group" aria-label="...">
								<a class="btn btn-default " href="viewSaleAdmin.php" role="button" data-toggle="tooltip" title="Detail"><span class="glyphicon glyphicon-zoom-in"></span> </a>
								<a class="btn btn-default " href="updateSaleAdmin.php" role="button" data-toggle="tooltip" title="Update"><span class="glyphicon glyphicon-pencil"></span> </a>
								
									<!-- Button trigger modal -->
									
										<button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">
										  <span data-toggle="tooltip" title="Get Receipt" class="glyphicon glyphicon-download-alt"></span> 
										</button>

										<!-- Modal -->
										<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
										  <div class="modal-dialog" role="document">
											<div class="modal-content">
											  <div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												<h4 class="modal-title" id="myModalLabel">Receipt #</h4>
											  </div>
											  <div class="modal-body">
												344bh32g4b2vg3uh2b3nv4h2233h4bijk
											  </div>
											  <div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="button" class="btn btn-primary">Copy to Clipboard</button>
											  </div>
											</div>
										  </div>
										</div><!-- /Modal -->
										
								<a class="btn btn-danger " href="deleteSaleAdmin.php" role="button" data-toggle="tooltip" title="Delete"><span class="glyphicon glyphicon-trash"></span> </a>
							</div>
						</td> 	
						   
					</tr>
				<?php 
				}
				?>
				</tbody>
		      </table>
			</div> <!--- /TABLE-RESPONSIVE -->
			<div class="form-group">
				<form class="form-horizontal" method="post">
				<input type="date" name="startDate"/>
				<input type="date" name="endDate"/>
				</form>
			</div>
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

