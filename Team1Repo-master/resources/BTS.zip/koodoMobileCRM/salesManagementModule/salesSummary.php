<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("sale");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>Sales Summary</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container">
			<h3>Summary for: 09/10/2015</h3>
			<!-- TABLE-RESPONSIVE -->
			<div class="table">
			  <table class="table table-bordered">
			  	<thead>
			  		<tr>
			  			<th class="col-sm-1 col-md-1"></th>
			  			<th class="col-sm-1 col-md-1">SHERIDAN</th>
			  			<th class="col-sm-1 col-md-1 success">JANE</th>
			  			<th class="col-sm-1 col-md-1">WOODSIDE</th>
			  			<th class="col-sm-1 col-md-1">TRETHEWEY</th>
			  		</tr>
			  	</thead>
				
				<tbody>
					<tr>
						<td>Koodo Activation</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Tab Redemption</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>DOA Exchanged</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Remorse Exchanges</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Unlocked Handsets</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Pre-paid Handsets</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Warranty</td>
						<td></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
		      </table>
			</div> <!--- /TABLE-RESPONSIVE -->

			<!-- Small modal -->
			<div class="col-md-offset-6">
				
				<button type="button" class="btn btn-success btn-lg" data-toggle="modal" data-target=".bs-example-modal-sm" ><span class="glyphicon glyphicon-envelope"></span><br>Send Report</button>

				<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
				  <div class="modal-dialog modal-md">
					<div class="modal-content">
						<div class="modal-header">
						<h4> Daily Sales Summary Report Sent</h4>
						</div>
						<div class="modal-body">
						<p> Date: 16/10/2015, To: Managers </p>
						</div>
					</div>
				  </div>
				</div>
			</div><!--/Small Modal -->
			
		</div>
		
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

