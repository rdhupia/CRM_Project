<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("sale");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>Sales Targets</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container ">
			
			<form class="form-horizontal ">
				<div class="row">
					<div class="form-group">
						
						
						<div class="col-sm-4">
							<input class="form-control" type="month" name="endDate">
						</div>
						<div>
							<!--<input class="form-control" type="submit" value="Submit">-->
							<a href="ManageSalesTarget.php" class="btn btn-default btn-sm col-sm-2">Select</a>
						</div>
					</div>
				</div>
					
				</div>					
			</form>
				
			<!-- TABLE-RESPONSIVE -->
			<div class="main-content container">
			  <table class="table table-bordered">
			  	<thead>
			  		<tr>
			  			<th class="col-md-3">User Name</th>
			  			<th class="col-md-4">Sales Target</th>
			  			<th class="col-md-4">Accessory Target</th>
			  		</tr>
			  	</thead>
				<form class="form-horizontal">
				<tbody>
					<tr>
						<td><input class="form-control" value="Bob" readonly=true type="text" name="Sales Target"></td>
						<td><input class="form-control" type="number" name="Sales Target"></td>
						<td><input class="form-control" type="number" name="Accessory Target"></td>
						<td><button class="btn btn-default btn-sm "> Update </button></td>
					</tr>
				</tbody>
				</form>
		      </table>
			</div> <!--- /TABLE-RESPONSIVE -->
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

