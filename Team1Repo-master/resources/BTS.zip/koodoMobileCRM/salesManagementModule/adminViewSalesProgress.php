<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("sales");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>View Sales Targets</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container">
			<h3>Sales Progress for: OCTOBER 2015</h3>
			<!-- TABLE-RESPONSIVE -->
			<div class="table">
			  <table class="table table-bordered">
			  	<thead>
			  		<tr>
						  <td>Name</td>
						  <td>Target</td>
						  <td>Current Sales</td>
						  <td>Percentage</td>
			  		</tr>
			  	</thead>
				<tbody>
					<tr>
						<td>Employee A</td>
						<td>10</td>
						<td>5</td>
						<td>50%</td>
						
					</tr>
					<tr>
						<td>Employee B</td>
						<td>20</td>
						<td>5</td>
						<td>25%</td>
						
					</tr>
					
				</tbody>
		      </table>
			</div> <!--- /TABLE-RESPONSIVE -->
			
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

