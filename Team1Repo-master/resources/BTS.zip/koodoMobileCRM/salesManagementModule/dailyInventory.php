<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("sale");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>Daily Counts</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container">
			<h3>Daily Inventory for: 09/10/2015</h3>
			<!-- Collapsible panels -->
			<form class="form-horizontal">
			<div class="panel-group col-md-6" id="accordion">
				<div class="panel panel-info" >
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#collapse1" data-toggle="collapse" data-parent="accordion">SIM INVENTORY</a></h4>
					</div>
					<div class="panel-collapse collapse in" id="collapse1"> 
						<div class="panel-body">
						
							<div class="form-group">
								<label for="countSS" class="col-sm-2 control-label">SS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countSS" placeholder="0">
								</div>
								<label for="countMS" class="col-sm-2 control-label">MS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countMS" placeholder="0">
								</div>
								<label for="countNS" class="col-sm-2 control-label">NS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countNS" placeholder="0">
								</div>
							 </div>
							 <div class="form-group">
								<label for="countPPSS" class="col-sm-2 control-label">PPSS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countPPSS" placeholder="0">
								</div>
								<label for="countPPMS" class="col-sm-2 control-label">PPMS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countPPMS" placeholder="0">
								</div>
								<label for="countPPNS" class="col-sm-2 control-label">PPNS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countPPNS" placeholder="0">
								</div>
							 </div>
						
						</div>
					</div>
				</div>
				<div class="panel panel-warning" >
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#collapse2" data-toggle="collapse" data-parent="accordion">PUBLIC MOBILE SIM</a></h4>
					</div>
					<div class="panel-collapse collapse" id="collapse2">
						<div class="panel-body">
						
							<div class="form-group">
								<label for="countPubSS" class="col-sm-2 control-label">Public SS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countPubSS" placeholder="0">
								</div>
								<label for="countPubMS" class="col-sm-2 control-label">Public MS</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countPubMS" placeholder="0">
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<div class="panel panel-success" >
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#collapse3" data-toggle="collapse" data-parent="accordion">PHONE INVENTORY</a></h4>
					</div>
					<div class="panel-collapse collapse" id="collapse3">
						<div class="panel-body">
						
							<div class="form-group">
								<label for="countC_GS3_B" class="col-sm-2 control-label">C_GS3_B</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countC_GS3_B" placeholder="0">
								</div>
								<label for="countC_MTG" class="col-sm-2 control-label">C_MTG</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countC_MTG" placeholder="0">
								</div>
								<label for="countC_NOTE2" class="col-sm-2 control-label">C_NOTE2</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countC_NOTE2" placeholder="0">
								</div>
							 </div>
							 <div class="form-group">
								<label for="countK_A392A" class="col-sm-2 control-label">K_A392A</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_A392A" placeholder="0">
								</div>
								<label for="countK_CORE_B" class="col-sm-2 control-label">K_CORE_B</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_CORE_B" placeholder="0">
								</div>
								<label for="countK_CORE_W" class="col-sm-2 control-label">K_CORE_W</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_CORE_W" placeholder="0">
								</div>
							 </div>
							 
							 
							 <div class="form-group">
								<label for="countK_GS3_B" class="col-sm-2 control-label">K_GS3_B</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_GS3_B" placeholder="0">
								</div>
								<label for="countK_GS3_W" class="col-sm-2 control-label">K_GS3_W</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_GS3_W" placeholder="0">
								</div>
								<label for="countK_GS4_B" class="col-sm-2 control-label">K_GS4_B</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_GS4_B" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countK_GS4_W" class="col-sm-2 control-label">K_GS4_W</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_GS4_W" placeholder="0">
								</div>
								<label for="countK_GS5" class="col-sm-2 control-label">K_GS5</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_GS5" placeholder="0">
								</div>
								<label for="countK_I4S_B" class="col-sm-2 control-label">K_I4S_B</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I4S_B" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countK_I4S_W" class="col-sm-2 control-label">K_I4S_W</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I4S_W" placeholder="0">
								</div>
								<label for="countK_I5C_WH" class="col-sm-2 control-label">K_I5C_WH</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I5C_WH" placeholder="0">
								</div>
								<label for="countK_I5S_GL" class="col-sm-2 control-label">K_I5S_GL</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I5S_GL" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countK_I6P_16GB" class="col-sm-2 control-label">K_I6P_16GB</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I6P_16GB" placeholder="0">
								</div>
								<label for="countK_I6_16GB" class="col-sm-2 control-label">K_I6_16GB</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I6_16GB" placeholder="0">
								</div>
								<label for="countK_I6_64GB" class="col-sm-2 control-label">K_I6_64GB</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_I6_64GB" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countK_LGG3" class="col-sm-2 control-label">K_LGG3</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_LGG3" placeholder="0">
								</div>
								<label for="countK_MTE_B" class="col-sm-2 control-label">K_MTE_B</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_MTE_B" placeholder="0">
								</div>
								<label for="countK_MTE_W" class="col-sm-2 control-label">K_MTE_W</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_MTE_W" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countK_MTG" class="col-sm-2 control-label">K_MTG</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_MTG" placeholder="0">
								</div>
								<label for="countK_NEX5" class="col-sm-2 control-label">K_NEX5</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_NEX5" placeholder="0">
								</div>
								<label for="countK_NOTE4" class="col-sm-2 control-label">K_NOTE4</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countK_NOTE4" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countP_D320" class="col-sm-2 control-label">P_D320</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countP_D320" placeholder="0">
								</div>
								<label for="countP_MTG" class="col-sm-2 control-label">P_MTG</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countP_MTG" placeholder="0">
								</div>
								<label for="countP_Y330" class="col-sm-2 control-label">P_Y330</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countP_Y330" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_7024W" class="col-sm-2 control-label">U_7024W</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_7024W" placeholder="0">
								</div>
								<label for="countU_FIERCE2" class="col-sm-2 control-label">U_FIERCE2</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_FIERCE2" placeholder="0">
								</div>
								<label for="countU_GGIO" class="col-sm-2 control-label">U_GGIO</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GGIO" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_GS2" class="col-sm-2 control-label">U_GS2</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GS2" placeholder="0">
								</div>
								<label for="countU_GS3_747" class="col-sm-2 control-label">U_GS3_747</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GS3_747" placeholder="0">
								</div>
								<label for="countU_GS3_999" class="col-sm-2 control-label">U_GS3_999</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GS3_999" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_GS3_999_32G" class="col-sm-2 control-label">U_GS3_999_32G</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GS3_999_32G" placeholder="0">
								</div>
								<label for="countU_GS4" class="col-sm-2 control-label">U_GS4</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GS4" placeholder="0">
								</div>
								<label for="countU_GS5" class="col-sm-2 control-label">U_GS5</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GS5" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_GW300" class="col-sm-2 control-label">U_GW300</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_GW300" placeholder="0">
								</div>
								<label for="countU_I4S" class="col-sm-2 control-label">U_I4S</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_I4S" placeholder="0">
								</div>
								<label for="countU_I5C" class="col-sm-2 control-label">U_I5C</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_I5C" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_I5_32G" class="col-sm-2 control-label">U_I5_32G</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_I5_32G" placeholder="0">
								</div>
								<label for="countU_L70" class="col-sm-2 control-label">U_L70</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_L70" placeholder="0">
								</div>
								<label for="countU_L90" class="col-sm-2 control-label">U_L90</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_L90" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_LIGHT" class="col-sm-2 control-label">U_LIGHT</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_LIGHT" placeholder="0">
								</div>
								<label for="countU_NEX4" class="col-sm-2 control-label">U_NEX4</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_NEX4" placeholder="0">
								</div>
								<label for="countU_NOTE2" class="col-sm-2 control-label">U_NOTE2</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_NOTE2" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_NOTE3" class="col-sm-2 control-label">U_NOTE3</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_NOTE3" placeholder="0">
								</div>
								<label for="countU_T599" class="col-sm-2 control-label">U_T599</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_T599" placeholder="0">
								</div>
								<label for="countU_XPZ" class="col-sm-2 control-label">U_XPZ</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_XPZ" placeholder="0">
								</div>
							 </div>
							 
							 <div class="form-group">
								<label for="countU_Y330" class="col-sm-2 control-label">U_Y330</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_Y330" placeholder="0">
								</div>
								<label for="countU_Z10" class="col-sm-2 control-label">U_Z10</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_Z10" placeholder="0">
								</div>
								<label for="countU_Z221" class="col-sm-2 control-label">U_Z221</label>
								<div class="col-sm-2">
									<input type="text" class="form-control" id="countU_Z221" placeholder="0">
								</div>
							 </div>
							 
						</div>
					</div>
				</div>
						
			</div>
				<div class="form-group col-md-6">
					<textarea class="form-control" rows="4" placeholder="Comments"></textarea>
				</div>								
				
				<div class="span7 text-right">
					<button type="submit" class="btn btn-success btn-lg">Submit</button>
				</div>
			
			</form>
		
		</div>
		
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

