<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("sale");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>View Sales Targets</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container">
			<h3>Sales Targets for: OCTOBER 2015</h3>
			<!-- TABLE-RESPONSIVE -->
			<div class="table">
			  <table class="table table-bordered">
			  	<thead>
			  		<tr>
			  			<th class="col-sm-2 col-md-2"></th>
			  			<th class="col-sm-1 col-md-1 warning">TARGET (T)</th>
			  			<th class="col-sm-1 col-md-1 success">MONTH TILL DATE (MTD)</th>
			  			<th class="col-sm-1 col-md-1">DIFFERENCE (T - MTD)</th>
			  			<th class="col-sm-1 col-md-1">Last Year This Month (LYTM)</th>
			  		</tr>
			  	</thead>
				
				<tbody>
					<tr>
						<td>Total Sales:</td>
						<td class="warning"></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Account Sales:</td>
						<td class="warning"></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Koodo Activation (K)</td>
						<td class="warning"></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Tab Redemption (T)</td>
						<td class="warning"></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Unlocked Handsets (U)</td>
						<td class="warning"></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Pre-paid Handsets (P)</td>
						<td class="warning"></td>
						<td class="success"></td>
						<td></td>
						<td></td>
					</tr>
					
				</tbody>
		      </table>
			</div> <!--- /TABLE-RESPONSIVE -->
			
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

