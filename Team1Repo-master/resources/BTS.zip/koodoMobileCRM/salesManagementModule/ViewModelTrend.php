<?php
	//This is Page Template
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	$header->writeHeader();
	$menu->writeMenu("sale");
	?>

		<!-- HEADER -->
		<header class="container">
			<div class="row">
				<h2>Model Trend</h2>
			</div>
		</header>
		<!-- /HEADER -->

		<!-- MAIN CONTENT -->
		<div class="main-content container">
			
			<form class="form-horizontal">
				<div class="row">
					<div class="form-group">
						<label class="control-label  col-sm-1">In:</label>
						<div class="col-sm-2">
						<input class="form-control" id="Location" Value="All stores" name="Location" type="text" required>
						</div>
						<label class="control-label  col-sm-1">From:</label>
						<div class="col-sm-2">
						<input class="form-control" type="date" name="startDate">
						</div>
						<label class="control-label  col-sm-1">To:</label>
						<div class="col-sm-2">
						<input class="form-control" type="date" name="endDate">
						</div>
						
							<div>
								<!--<input class="form-control" type="submit" value="Submit">-->
								<a href="ViewModelTrend.php" class="btn btn-default btn-sm">Search</a>
							</div>
						</div>
					</div>
					<button class="btn btn-success ">
					View all
					</button>
					<button class="btn btn-default btn-sm">
					<label class="checkbox-inline">
						<input type="checkbox" id="deleted" value="deleted"> deleted
					</label>
					</button>
					<button class="btn btn-default btn-sm">
					<label class="checkbox-inline">
						<input type="checkbox" id="returned" value="returned"> returned
					</label>
					</button>
				
				</div>					
			</form>
				
			<!-- TABLE-RESPONSIVE -->
			<div class="main-content container">
			  <table class="table table-bordered">
			  	<thead>
			  		<tr>
			  			<th class="col-sm-1 col-md-1">Model</th>
			  			<th class="col-sm-1 col-md-1">S</th>
			  			<th class="col-sm-2 col-md-2">W</th>
			  			<th class="col-sm-1 col-md-1">T</th>
			  			<th class="col-sm-2 col-md-2">J</th>
			  			<th class="col-sm-2 col-md-2">Y</th>
			  			<th class="col-sm-1 col-md-1">Sum</th>
			  		</tr>
			  	</thead>
				
				<tbody>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
		      </table>
			</div> <!--- /TABLE-RESPONSIVE -->
		</div>
		<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

