<?php
	//This is just for the mock up purpose.
	include("library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>Search Result</h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<div class="row">
		<h3>Sales Search Result</h3>
		<hr/>
	</div>
				
				
	<table class="table table-striped">
		<thead>
			<tr>
				<th>SalesId</th>
				<th>Phone #</th>
				<th></th>
				<th>Receipt</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>302233</td>
				<td>416420666</td>
				<td><a href="../salesManagementModule/viewSaleReturn.php">View / Process Return</a></td> 	
				<td>
				<!-- Button trigger modal -->									
					<button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">
					  <span data-toggle="tooltip" title="Get Receipt" class="glyphicon glyphicon-download-alt"></span> 
					</button>

					<!-- Modal -->
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel">Receipt #</h4>
						  </div>
						  <div class="modal-body">
							344bh32g4b2vg3uh2b3nv4h2233h4bijk
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button type="button" class="btn btn-primary">Copy to Clipboard</button>
						  </div>
						</div>
					  </div>
					</div><!-- /Modal -->
				</td>
			</tr>
		</tbody>
	</table>

	 <br><br>			
	 <div class="row">
		<h3>Membership Search Result</h3>
		<hr/>
	</div>
				
				
	<table class="table table-striped">
		<thead>
			<tr>
				<th>MembershipId</th>
				<th>Phone #</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>100000</td>
				<td>6471111111</td>
				<td><a href="../membershipManagementModule/viewMembership.php">Detail</a></td> 	
			</tr>
		</tbody>
	</table>
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>