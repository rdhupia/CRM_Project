<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>View Credit Requests</h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<table class="table table-bordered">
		<thead>
			<tr >
				<td>#</td>
				<td>Requested Date & Time</td>
				<td>Requested By</td>
				<td>Location</td>
				<td>Membership ID</td>
				<td>Amount</td>
				<td>Comment</td>
				<td>Status</td>
				<td></td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>2015-09-20 11:11</td>
				<td>ABC</td>
				<td>Y</td>
				<td>100101</td>
				<td>15</td>
				<td>Requested by ABC: Mistake Fix </td>
				<td>Requested</td>			
				<td><a href="adminManageCreditRequest.php">Update</a></td>
			</tr>
			<tr>
				<td>2</td>
				<td>2015-09-20 11:11</td>
				<td>CDC</td>
				<td>W</td>
				<td>101101</td>
				<td>100</td>
				<td>On 2015-10-11: Please do it<br>Updated on 2015-10-11: Approved by Manager1</td>
				<td>approved</td>
				<td></td>
			</tr>
			<tr>
				<td>3</td>
				<td>2015-09-20 11:11</td>
				<td>EDC</td>
				<td>Y</td>
				<td>111111</td>
				<td>20</td>
				<td>On 2015-10-11: Please do it<br>Updated on 2015-10-11: Declined by Manager1</td>
				<td>Declined</td>
				<td></td>	
			</tr>
		</tbody>
	</table>
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>