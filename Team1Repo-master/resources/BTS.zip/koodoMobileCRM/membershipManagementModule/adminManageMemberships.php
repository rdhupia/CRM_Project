<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
	?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>Manage Memberships<h/h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">			
	<table class="table table-striped">
		<thead>
			<tr >
				<th>Member ID</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Phone Number</th>
				<th>E mail</th>
				<th>E mail password</th>
				<th>VIP</th>
				<th>VIP Start date</th>
				<th>Register date</th>
				<th>balance</th>
				<th>Registered By</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="viewMembership.php">Deactivate VIP</a>
				</td>
			</tr>
			<tr>
				<td>100001</td>
				<td>Jung</td>
				<td>Choi</td>
				<td>64741111111</td>
				<td>aabbcc@hotmail.com</td>
				<td></td>
				<td>y</td>
				<td>2015-11-05</td>
				<td>2015-11-04</td>
				<td>0</td>
				<td>ABCD</td>
				<td>
					<a class="btn btn-danger" href="adminManageMemberships.php">Deactivate VIP</a>
				</td>
			</tr>					
		</tbody>
	</table>
	<div class="row text-center">
		<form class="form-inline">
			<div class="form-group">
				<input type="text" class="form-control"  value=""
					 type="text" placeholder="Membership ID" name="membershipID" maxlength="6">
			</div>
			<button type="submit" title="Search" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
		</form>
		
	</div>
	<div class="row text-center">
		<b>1</b> <a>2</a> <a>3</a> <a>4</a> <a>5</a> <a>6</a> <a>7</a> <a>8</a> <a>9</a> <a>10</a> <a>[NEXT]</a>
	</div>
	
</div>
	<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>