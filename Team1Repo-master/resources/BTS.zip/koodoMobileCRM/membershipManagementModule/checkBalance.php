 <?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();?>
<body>
	<div class="container body-content">
		<div class="row text-center">
			<div class="col-md-6 col-md-offset-3">
				<div class="row">
					<img src="../img/wc_logo_large_transparent.png" class="img img-responsive">
				</div>
				<h2>Membership Credit Balance Check</h2><hr>
				<br>
				<div class="bg-info">
					Check your WorldComm Membership Balance Here!<br>
					Enter your membership id on the card below and click submit
				</div>
				<br>
				<form method="post" >
					<div class="row">
						<div class="col-md-8">
							<input name="membershipId" placeholder="Enter Your Membership Id" class="form-control">
						</div>
						<div class="col-md-4">
							<input name="submit" type="submit" class="form-control">
						</div>
					</div>
				</form>
			
			<br>
			<hr/>
			<br>
			<div class="row">
				<h3> Search Result </h3>
				Membership ID: 229392<br>
				Balance : $2253.00
			</div>
		</div>
	</div>
	</div>
	<br>	
	<hr>
			<div class="row text-center">
				<b>Membership Terms and Conditions</b><br>
				Only one membership card can be used for each transaction. World Comm.-CT membership and its membership credit is not transferrable. Membership card must be presented to invoke membership privileges. Membership services can only be used at the locations specified on the membership card. Membership credit does not have any monetary value. Membership credit cannot be used for handset purchases or Koodo mobile service payments. Terms and conditions are subject to change without notice. VIP membership expires in one year from the date of VIP activation. Membership owners are responsible to keep the membership card and any personal information safe. World Comm.-CT will not be responsible for any loss of the credit or services due to the owners' mistakes. There is a replacement fee is $10 if the card is lost. Friend referral credit will be applied 8 weeks after the activation. Friend referral credits are void if the referred account is being cancelled within 8 weeks post activation. VIP premium terms and services can be changed without notice All products & services purchased with WorldComm membership credit are final sale. Credit received for Koodo activation must be fully paid if customer return or cancel either of their handset or service. Membership credit purchases cannot be combined with any other store promotions. Credit restore for lost/stolen card may take up to 4 weeks. Any disagreement/dispute over membership credit balance will be settled by the transaction records on our system whereas, World Comm.-CT has no obligation to prove the transaction records to customers. Membership registration is final sale.
			</div>
		</div>
		</div>
	</div>
<?php
	$footer->writeFooter();
?>