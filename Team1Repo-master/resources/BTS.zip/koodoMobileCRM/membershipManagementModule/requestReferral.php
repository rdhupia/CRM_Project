<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
?>
<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>Referral Request</h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<form class="form-horizontal" method="POST">
		<div class="form-group">
			<label class="control-label  col-md-4">Membership Id (Referring)</label>
			<div class="col-md-4">
				<input class="form-control" placeholder="Membership Id" name="membershipIdRegistered"  maxlength="6" required pattern="[\d]{6}" title="6 numberic digits only.">
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Membership Id (Reffered)</label>
			<div class="col-md-4">
				<input class="form-control" placeholder="Membership Id" name="membershipIdGuest"  maxlength="6" required pattern="[\d]{6}" title="6 numberic digits only.">
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Phone Number (Reffered)</label>
			<div class="col-md-4">
				<input class="form-control" placeholder="Phone Number" name="phoneNumber"  maxlength="10" required pattern="[\d]{10}" title="10 numeric digits only">
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Account Number (Reffered)</label>
			<div class="col-md-4">
				<input class="form-control" placeholder="Account Number" name="accountNumber"  maxlength="10" required>
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-4">
			</div>
			<div class="col-md-4">
				<a href="../employeeManagementModule/home.php" class="btn btn-success form-control">Submit</a>
			</div>
		</div>	
	</form>
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>