<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
	?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>View Credit Transactions<h/h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">			
	<table class="table table-striped">
		<thead>
			<tr>
				<td>#</td>
				<td>Date & Time</td>
				<td>Location</td>
				<td>Updated By</td>
				<td>Origin Balance</td>
				<td>Amount Changed</td>
				<td>New Balance</td>
				<td>Transaction Type</td>
				<td>Cello ID</td>		
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>43</td>
				<td>2015-10-04 </td>
				<td>S</td>
				<td>EUNJI</td>
				<td>0</td>
				<td>0</td>
				<td>0</td>
				<td>Activation Credit</td>
				<td></td>
			</tr>
			<tr>
				<td>46</td>
				<td>2015-11-05</td>
				<td>S</td>
				<td>EUNJI</td>
				<td>0</td>
				<td>50</td>
				<td>50</td>
				<td>Addition</td>
				<td></td>
			</tr>
			<tr>
				<td>48</td>
				<td>2014-11-05 </td>
				<td>S</td>
				<td>KKK</td>
				<td>50</td>
				<td>-35</td>
				<td>15</td>
				<td>Redemption</td>
				<td>2349382738493</td>
			</tr>
		</tbody>
	</table>
	<a class="btn btn-primary" href="viewMembership.php">Back</a>
</div>
	<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>















