<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>View VIP Menu<h/h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<form class="form-horizontal" method="post">
		<div class="form-group">
			<label class="control-label  col-md-4">Membership Id</label>
			<div class="col-md-4">
				<input class="form-control" name="membershipId"  maxlength="6" readonly value="100001">
			</div>
		</div>
		<div class="form-group">
		<label class="control-label col-md-4">Service</label>
		<div class="col-md-4">
			<select name = "service" class="form-control" required>
						<option value="">--Select Service--</option>
						<option  value="screenProtector">Screen Protector</option>
						<option  value="phoneCleaning">Phone Cleaning</option>
						<option  value="phoneOpt">Phone Optimization</option>
						<option  value="batteryOpt">Battery Optimization</option>
						<option  value="phoneDiscount">Phone Discount</option>
						<option  value="unlockDiscount">Unlock Discount</option>
						<option  value="batteryCharge">Battery Charge</option>
						<option  value="contactBackup">Contact Backup</option>
						<option  value="accDiscount">Accessory Discount</option>
					</select>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label  col-md-4">Amount</label>
			<div class="col-md-4">
				<input type="numbers" required min="0" name="amount" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label class="control-label  col-md-4">Cello Transaction Number</label>
			<div class="col-md-4">
				<input class="form-control"  placeholder="Cello Transaction Number" maxlength="13" name="celloId" pattern="[\d]{13}" title="Cello T.N. must be 13 numeric digits only.">
			</div>
		</div>			
		<div class="form-group">
			<label class="control-label  col-md-4">Username</label>
			<div class="col-md-4">
				<input class="form-control" readonly name="userName"   maxlength="5" value="EDC">
			</div>
		</div>
		<div class="form-group">
			<label class="control-label  col-md-4">Password</label>
			<div class="col-md-4">
				<input class="form-control" placeholder="Password" id="password" name="password"   type="password"  maxlength="5" required pattern="[a-zA-Z0-9]{3,5}" title="3 to 5 alpha, numeric digits only">
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-4"></label>
			<div class="col-md-4">
				<input class="form-control" type="submit" value="Submit">
			</div>
		</div>
	</form>			
	<div class="row">
		<div class=" text-center col-md-4 col-md-offset-4">
			<span class="bg-danger"></span>
		</div>
	</div>	
	<div class="row">
		<h3>VIP Trasaction History</h3>
		<hr/>
	</div>				
	<table class="table table-striped">
		<thead>
			<tr>
				<th>#</th>
				<th>Date & Time</th>
				<th>Location</th>
				<th>Updated By</th>
				<th>Service</th>
				<th>Amount</th>
				<th>Cello ID</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>3</td>
				<td>2015-10-05</td>
				<td>Y</td>
				<td>EDC</td>
				<td>VIP Activation</td>
				<td></td>
				<td>2394802938490</td>
			</tr>
			<tr>
				<td>6</td>
				<td>2015-10-07</td>
				<td>Y</td>
				<td>EDC</td>
				<td>Phone Cleaning</td>
				<td></td>
				<td>2394802938490</td>
			</tr>
			<tr>
				<td>8</td>
				<td>2015-10-07</td>
				<td>Y</td>
				<td>EDC</td>
				<td>Accessory Discount</td>
				<td>$20</td>
				<td>2394802938490</td>
			</tr>
		</tbody>
	</table>
	<a class="btn btn-primary" href="viewMembership.php">Back</a>
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>