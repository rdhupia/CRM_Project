<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
	?>

<!-- HEADER -->
<header class="container">
		<div class="row">
			<h2>View Membership Details</h2>
		</div>
</header>
<!-- /HEADER -->

<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<table class="table table-striped">
		<thead>
			<tr>
				<th>Membership Menu</th>
				<td>
					<a class="btn btn-primary" href="addMembership.php">Update Profile</a>
					<a class="btn btn-primary" href="activateVIP.php">Activate VIP</a>
					<a class="btn btn-primary" href="viewVIPMenu.php">VIP Menu</a>
					<a class="btn btn-primary" href="updateCredit.php">Update Credit</a>
					<a class="btn btn-primary" href="viewCreditTransactions.php">View Credit Transaction</a>
					<a class="btn btn-primary" href="viewRequestsStatus.php">View Requests Status</a>
				</td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Membership Id</td>
				<td> 100001</td>
			</tr>
			<tr>
				<td>Name</td>
				<td>Jung Choi</td>
			</tr>
			<tr>
				<td>Phone Number</td>
				<td>6473823392</td>
			</tr>
			<tr>
				<td>E-Mail</td>
				<td>jgchoi@hotmail.com</td>
			</tr>
			<tr>
				<td>E-Mail Password</td>
				<td></td>
			</tr>
			<tr>
				<td>Mem. Start Date</td>
				<td>2015-06-04 </td
			></tr>
			<tr>
				<td>Credit Balance</td>
				<td>$0</td>
			</tr>
			<tr>
				<td>VIP Start Date</td>
				<td></td>
			</tr>
			<tr>
				<td>Address</td>
				<td>70 The Pond Rd.</td>
			</tr>
			<tr>
				<td>Comment</td>
				<td></td>
			</tr>
		</tbody>
	</table>			
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>















