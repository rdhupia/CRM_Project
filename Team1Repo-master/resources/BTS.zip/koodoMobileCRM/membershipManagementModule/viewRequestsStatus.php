<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
	?>

<!-- HEADER -->
	<header class="container">
		<div class="row">
			<h2>View Request History</h2>
		</div>
	</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">		
	<div class="row">
		<table class="table table-striped">
			<thead>
				<tr>
				<th>#</th>
				<th>Date & Time</th>
				<th>Requested By</th>
				<th>Type</th>
				<th>Status</th>
				<th>Comment</th>
			</tr>
			</thead>
			<tbody>
				<tr>
					<td>1</td>
					<td>2015-10-23</td>
					<td>EED</td>
					<td>Referral</td>
					<td>Pending</td>
					<td></td>
				</tr>
				<tr>
					<td>2</td>
					<td>2015-10-26</td>
					<td>EKD</td>
					<td>Credit Addition Reqest</td>
					<td>Approved</td>
					<td>Manager: Account checked.</td>
				</tr>	
			</tbody>
		</table>
		<a class="btn btn-primary" href="viewMembership.php">Back</a>
	</div>
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>















