<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
	?>

<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<div class="row">
		<h3>Membership Rule (Regular)</h3>
		<hr/>
	</div>
	1. Sign up fee : $10 or free with accessory purchase<Br>
	2. Referral Credit : $15<Br>
	3. Accessory discount : 10%<Br>
	<Br>
	
	<div class="row">
		<h3>Membership Rule (VIP)</h3>
		<hr/>
	</div>
				
	<Br>
	1. Sign up fee : $30 <Br>
	2. Referral Credit : $25<Br>
	3. Accessory Discount : 10%<Br>
	4. Handset Discount : $10<Br>
	5. Period : 1 Year<Br>
	6. VIP Privileges :<Br>
	a) 2 Screen protector + Installation<Br> 
	b) 2 Handset cleaning<Br>
	c) 2 Smart Phone Optimization<Br>
	d) 2 Battery calibration<Br>
	e) Unlocking Discount 13%<Br>
	f) Phone charging service<Br>
	g) Contact back-up service <Br>
	<Br>
	<div class="row">
		<h3>Membership Number</h3>
		<hr/>
	</div>
				
	1. Membership management system use 6 digits for membership number<Br>
	2. First digit is set by the type of the card<Br>
	a) '9' for VIP card<Br>
	b) '1' for regular card<Br>
	3. Following 5 digits are same as last 5 digits from the membership card number<Br>
	<Br>
	E.g) If regular membership card has "64735 64650 001305", membership number is "101305"<Br>
	E.g) If VIP membership card has "20141 00000 000025", membership number is "900025"<Br>
	<Br>
	* Possible range for regular card: 100001 ~ 101700<Br>
	* Possible range for VIP card: 900001 ~ 900300<Br>
	<Br>
	<div class="row">
		<h3>Membership Terms and Condition</h3>
		<hr/>
	</div>
				
	<h5> Last modified on 2015-10-01 </h5>
	<Br>
	1. Only one membership card can be used for each transaction.<Br> 
	2. World Comm.-CT membership and its membership credit is not transferrable.<Br>
	3. Membership card must be presented to invoke membership privileges.<Br>
	4. Membership services can only be used at the locations specified on the membership card.<Br>
	5. Membership credit does not have any monetary value.<Br>
	6. Membership credit cannot be used for handset purchases or Koodo mobile service payments<Br>
	7. Terms and conditions are subject to change without notice<Br>
	8. VIP membership expires in one year from the date of VIP activation.<Br>
	9. Membership owners are responsible to keep the membership card and any personal information safe. World Comm.-CT will not be responsible for any loss of the credit or services due to the owners' mistakes.<Br>
	10. There is a replacement fee is $10 if the card is lost.<Br>
	11. Friend referral credit will be applied 8 weeks after the activation.<Br>
	12. Friend referral credits are void if the referred account is being cancelled within 8 weeks post activation.<Br>
	13. VIP premium terms and services can be changed without notice<Br>
	14. All products & services purchased with WorldComm membership credit are final sale.<Br>
	15. Credit received for Koodo activation must be fully paid if customer return or cancel either of their handset or service.<Br>
	16. Membership credit purchases cannot be combined with any other store promotions.<Br>
	17. Credit restore for lost/stolen card may take up to 4 weeks.<Br>
	18. Any disagreement/dispute over membership credit balance will be settled by the transaction records on our system whereas, World Comm.-CT has no obligation to prove the transaction records to customers.<Br>
	19. Membership registration is final sale.<Br>
	</div>
</div>
<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>