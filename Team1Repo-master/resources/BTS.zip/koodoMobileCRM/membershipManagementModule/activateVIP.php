<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
	?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>Activate VIP<h/h2>
	</div>
</header>
<!-- Main -->		
<div class="main-content container-fluid">
	<form class="form-horizontal" method="POST">
		<div class="form-group">
			<label class="control-label  col-md-4">Membership Id</label>
			<div class="col-md-4">
				<input class="form-control" name="membershipId"  maxlength="6" readonly value="100001">
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Name</label>
			<div class="col-md-4">
				<input class="form-control" value="Jung Geon Choi" readonly>
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Phone Number</label>
			<div class="col-md-4">
				<input class="form-control"  readonly value="6471234567">
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Cello Transaction Number</label>
			<div class="col-md-4">
				<input class="form-control"  placeholder="Cello Transaction Number" maxlength="13" name="celloId" pattern="[\d]{13}" title="Cello T.N. must be 13 numeric digits only.">
			</div>
		</div>
					
		<div class="form-group">
			<label class="control-label  col-md-4">Username</label>
			<div class="col-md-4">
				<input class="form-control" readonly name="userName"   maxlength="5" value="EDC">
			</div>
		</div>
		
		<div class="form-group">
			<label class="control-label  col-md-4">Password</label>
			<div class="col-md-4">
				<input class="form-control" placeholder="Password" id="password" name="password"   type="password"  maxlength="5" required pattern="[a-zA-Z0-9]{3,5}" title="3 to 5 alpha, numeric digits only">
			</div>
		</div>

		<div class="form-group">
			<label class="col-md-4"></label>
			<div class="col-md-4">
				<a href="viewMembership.php" class="btn btn-primary form-control">Activate VIP</a>
			</div>
		</div>
	</form>

	<div class="row">
		<div class="text-center col-md-4 col-md-offset-4">
			<span class="bg-danger"></span>
		</div>
	</div>	
</div>

<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>

