<?php
	include("../library/library.php");
	$menu = new Menu();
	$header = new Header();
	$footer = new Footer();
	
	$header->writeHeader();
	$menu->writeMenu("membership");
?>

<!-- HEADER -->
<header class="container">
	<div class="row">
		<h2>View Referral Requests</h2>
	</div>
</header>
<!-- /HEADER -->
<!-- MAIN CONTENT -->
<div class="main-content container-fluid">
	<table class="table table-bordered">
		<thead>
			<tr>
				<td>#</td>
				<td>Requested Date & Time</td>
				<td>Requested By</td>
				<td>Memb. ID Requested</td>
				<td>Memb. ID Referred</td>
				<td>Phone Number</td>
				<td>Account Number</td>
				<td>Status</td>
				<td>Change Status</td>
				<td>Comment</td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>2015-10-04</td>
				<td>CCC</td>
				<td>100000</td>
				<td>100001</td>
				<td>6471234123</td>
				<td>29331122</td>
				<td>Requested</td>	
				<td>
					<form class="form" method="post">
						<div class="form-group">
							<input class="form-control" name="comment"   placeholder="comment">
						</div>
						<div class="row">
							<div class="col-md-4"><button type="button" class="btn btn-success" title="approved"><span class="glyphicon glyphicon-ok"></span></button></div>
							<div class="col-md-4"></div>
							<div class="col-md-4"><button type="button" class="btn btn-danger" title="Declined"><span class="glyphicon glyphicon-remove"></span></button></div>
						</div>
					</form>
				</td>
				<td></td>
			</tr>
			<tr>
				<td>2</td>
				<td>2015-10-04</td>
				<td>CCC</td>
				<td>100000</td>
				<td>100001</td>
				<td>6471234123</td>
				<td>29331122</td>
				<td>Declined</td>	
				<td></td>
				<td>Updated on 2015-11-1 by Manager 1: <br>Service Cancelled</td>
			</tr>
			<tr>
				<td>3</td>
				<td>2015-10-04</td>
				<td>CCC</td>
				<td>100000</td>
				<td>100001</td>
				<td>6471234123</td>
				<td>29331122</td>
				<td>Approved</td>	
				<td></td>
				<td>Update on 2015-11-03 by Manager 3:<br> Checked, approved</td>
			</tr>
		</tbody>
	</table>
</div>
	<!-- /MAIN CONTENT -->

<?php
	$footer->writeFooter();
?>